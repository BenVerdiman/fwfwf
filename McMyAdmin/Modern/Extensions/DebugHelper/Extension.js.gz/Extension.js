﻿//Make sure to replace 'Extensions.SampleExtension' below with 'Extensions.YourExtensionName'

Extensions.DebugHelper = {};
Extensions.DebugHelper.CreateTab = true;
Extensions.DebugHelper.Name = "Debug Helper Extension";
Extensions.DebugHelper.Author = "CubeCoders Limited";
Extensions.DebugHelper.TabTitle = "Debug";

Extensions.DebugHelper.Init = function () {
    APICommands.WriteThreadStats = "WriteThreadStats";
    APICommands.SetThreadWake = "SetThreadWake";

    $("#tabhead_DebugHelper").hide();
    $("#mainlogo").click(function()
    {
        $("#tabhead_DebugHelper").show();
        $("#writeThreads").click(writeST);
        $("#setThreadState").click(setST);
    });
};

function writeST()
{
    performAction(APICommands.WriteThreadStats);
}

function setST() {
    var checked = $("#setEnabled").is(":checked");
    var id = $("#setThreadID").val();
    requestData(APICommands.SetThreadWake, { ThreadID: id, Awake: checked }, function () { });
}

